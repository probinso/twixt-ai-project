import java.awt.Point;

public interface boardFunc{
    /*
      boardFunc interface provides general operations
      on boards
    */
    public Boolean isValid(BoardStore param);
    /*should return if the board function is a valid option*/
    
    public BoardStore function(BoardStore param);
    /*should return board iff isValid*/
    public Point retrieve();
}

