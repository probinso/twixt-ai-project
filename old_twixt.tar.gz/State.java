import java.awt.*;
import java.util.Vector;
import java.util.Collections;

public class State{

    public BoardStore Self; 

    public AIBase myAI;

    public int score = -200;
    
    public Point P = new Point(-3,-3);
    /*
      private static final int I_FIRST = -2147483648;
      private static final int I_LAST  =  2147483647;
      
      public int alpha = I_FIRST;
      public int beta  = I_LAST;
    */
    
    public Vector<boardFunc> validFuncs = new Vector<boardFunc>();

    /**/
    public State(BoardStore B, int turn, AIBase ai)
    {
	    // State does not copy board
	    // It only stores it by reference
	    this.Self = B;
        myAI = ai;
	    Vector<Point> M = myAI.forwardPrune(myAI.findMoves(B.Copy()),B.Copy(), turn);
        
	    for (Point p : M)
	    {
	        final int x = p.x;
	        final int y = p.y;
	        
	        validFuncs.add(new boardFunc(){
		        public Boolean isValid(BoardStore Board){return (Board.pegs[x][y].status == 0); }
		        public BoardStore function(BoardStore Board){boolean b = Board.placePeg( x , y ); return Board; }
		        public Point retrieve(){return new Point(x,y);}
		    });
	}
	
	/*
	for (int i = 0; i < Ops.size(); i++)
	    if (Ops.elementAt(i).isValid(this.Self))
		this.validFuncs.add(Ops.elementAt(i));
	*/
    }

    /**/
    public int Eval(int player){
	    return this.Self.Eval(player, myAI);
    }
    /**/	
}
