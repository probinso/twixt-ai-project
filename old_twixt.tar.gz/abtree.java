import java.awt.*;

public class abtree{
    
    /*
      There is full working examples of this running code in ab_tmp/ using tic tac toe
    */
    
    private int max(int a, int b){return (a<b)?b:a;}
    private int min(int a, int b){return (a<b)?a:b;}
    
    private int myTurn = -5;
    
    private final int I_FIRST = -2147483648;
    private final int I_LAST  =  2147483647;
    
    private AIBase ai;
    
    public Point ABsearch(BoardStore B,int depth, AIBase in_ai){
    ai = in_ai;
	myTurn = globals.playerTurn;
	State S = maxValue(new State(B, myTurn, ai),depth,I_FIRST,I_LAST, myTurn);
	return S.P;
    }
    
    public State maxValue(State S,int depth,int alpha, int beta, int turn){
	//System.err.println("inverse depth from max is : "+ depth);
	
	State Ret = S;
	
	if (depth*S.validFuncs.size()==0){
	    Ret.score = Ret.Eval(myTurn);
	    return Ret;
	}
        
	for (int i = 0; i < S.validFuncs.size(); i++){
	    State Tmp = new State(S.validFuncs.elementAt(i).function(S.Self).Copy(), myTurn, ai); 
	    /*  
	     * P stores the point moved to from the current function
	     */
	    Tmp.P = S.validFuncs.elementAt(i).retrieve();
        int theirTurn = (myTurn == 1) ? 2 : 1;
	    State Get = minValue(Tmp,depth-1,alpha,beta, theirTurn);
	    Tmp.score = Get.score;
	    
	    if (alpha < Get.score){
		Ret = Tmp;
		alpha = Ret.score;
	    }
	    
	    if (alpha >= beta){
		Ret.score = beta;
		return Ret;
	    }
	    
	}
	return Ret;
    }
    
    public State minValue(State S,int depth,int alpha, int beta, int turn){
	//System.err.println("inverse depth from min is : "+ depth);
	State Ret = S;
	
	if (depth*S.validFuncs.size()==0){
	    Ret.score = Ret.Eval(myTurn);
	    return Ret;
	}
	
	for (int i = 0; i < S.validFuncs.size(); i++){
	    
	    State Tmp = new State(S.validFuncs.elementAt(i).function(S.Self).Copy(), myTurn, ai);

	    /*  
	     * P stores the point moved to from the current function
	     */
	    Tmp.P = S.validFuncs.elementAt(i).retrieve();

        int theirTurn = (myTurn == 1) ? 2 : 1;
	    State Get = maxValue(Tmp,depth-1,alpha,beta, theirTurn);
	    Tmp.score = Get.score;
	    
	    if (Get.score<beta){
		Ret = Tmp;
		beta = Ret.score;
	    }
	    
	    if (beta <= alpha){
		Ret.score = alpha;
		return Ret;
	    }
	}
	
	return Ret;
    }
}
