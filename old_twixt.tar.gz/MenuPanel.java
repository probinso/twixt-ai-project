import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuPanel extends JPanel implements ActionListener
{
    String[] playerTypes = {"Select Player Type", "Human", "Rando Calrissian", "Greedo", "Chewblocka", "Advancellor Palpatine", "THE CHOSEN ONE"};
	String[] aiTypes = {"Select AI Type", "Rando Calrissian", "Greedo", "Chewblocka", "Advancellor Palpatine", "THE CHOSEN ONE"};
	JComboBox aiBox;
	JComboBox p1Box;
    JComboBox p2Box;
    JLabel p1Lbl;
    JLabel p2Lbl;
	JLabel aiLabel;
	JLabel p1;
    JLabel p2;
    JButton startButton;
    JButton autoChooseButton;
	JButton againButton;
	
    public MenuPanel()
    {
        aiBox = new JComboBox(aiTypes);
	    p1Box = new JComboBox(playerTypes);
        p2Box = new JComboBox(playerTypes);
        p1Lbl = new JLabel("Player 1");
        p2Lbl = new JLabel("Player 2");
	    aiLabel = new JLabel("AI Types");
	    p1 = new JLabel();
        p2 = new JLabel();
        startButton = new JButton("Start!");
        autoChooseButton = new JButton("Choose for me.");
	    againButton = new JButton("Start Over?");

        p1Box.addActionListener(this);
        p2Box.addActionListener(this);
        startButton.addActionListener(this);
        aiBox.addActionListener(this);
        autoChooseButton.addActionListener(this);
        againButton.addActionListener(this);

        restartMenu();
    }

    public void restartMenu()
    {
        setLayout(new GridLayout(25, 1));
	
        globals.started = false;
        globals.winner = 0;
        globals.playerTurn = 1;
    
        this.removeAll();

        p1Lbl.setForeground(Color.BLUE);
        p1Lbl.setHorizontalAlignment(SwingConstants.CENTER);

        p2Lbl.setForeground(Color.RED);
        p2Lbl.setHorizontalAlignment(SwingConstants.CENTER);

        p1.setHorizontalAlignment(SwingConstants.CENTER);
        p2.setHorizontalAlignment(SwingConstants.CENTER);
  
        globals.gb.restart();
        this.removeAll();
        this.begin();
        this.paintImmediately(this.getVisibleRect());
        this.revalidate();
    }

    public synchronized void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        this.setBackground(Color.GRAY);
        
        if(globals.started && globals.winner == 0)
        {
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Algerian",Font.BOLD,15));
            if (globals.playerTurn == 1)
                g.drawString(">", 20, 48);
            else if (globals.playerTurn == 2)
                g.drawString(">", 20, 135);
        }
    }

    public void begin()
    {
        add(new JLabel(" "));
        add(p1Lbl);
        
        p1Box.setModel(new DefaultComboBoxModel(playerTypes));
        add(p1Box);
        
        add(new JLabel(" "));
        add(p2Lbl);
        
        p2Box.setModel(new DefaultComboBoxModel(playerTypes));
        add(p2Box);
        
        add(new JLabel(" "));
        add(startButton);
        add(new JLabel(" "));

    }

    public void updatePlayerTurn()
    {
        this.removeAll();
        add(new JLabel(" "));

        add(p1Lbl);
        add(p1);

        add(new JLabel(" "));

        add(p2Lbl);
        add(p2);
        add(new JLabel(" "));
        add(new JLabel(" "));
        add(new JLabel(" "));
        add(new JLabel(" "));
		if ((globals.players[1] == 0) || (globals.players[2] == 0))
        {
            int aiIndex = aiBox.getSelectedIndex();
            add(aiLabel);
            aiBox.setModel(new DefaultComboBoxModel(aiTypes));
            aiBox.setSelectedIndex(aiIndex);
            add(aiBox);
            add(new JLabel(" "));
            add(autoChooseButton);
        }
        add(new JLabel(" "));
        add(new JLabel(" "));
        add(new JLabel(" "));
        add(new JLabel(" "));
        add(new JLabel(" "));
        add(againButton);

        this.paintImmediately(this.getVisibleRect());
        this.revalidate();
    }


    public void printGameOver()
    {
        this.removeAll();

        add(new JLabel(" "));
        add(new JLabel("Game Over!"));

        add(new JLabel(" "));

        if (globals.winner == 1)
        {
            add(new JLabel("Winner is:"));
            add(p1Lbl);
            add(p1);

            add(new JLabel(" "));

            add(new JLabel("Loser is:"));
            add(p2Lbl);
            add(p2);
        }
        else if (globals.winner == 2)
        {
            add(new JLabel("Winner is:"));
            add(p2Lbl);
            add(p2);

            add(new JLabel(" "));

            add(new JLabel("Loser is:"));
            add(p1Lbl);
            add(p1);
        }
        else if (globals.winner == 3)
        {
            add(new JLabel("Draw!"));
        }

        add(new JLabel(" "));

        add(againButton);

        this.paintImmediately(this.getVisibleRect());
        this.revalidate();
    }

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource().equals(startButton))
        {
            int p1index = p1Box.getSelectedIndex();
            int p2index = p2Box.getSelectedIndex();
            
            globals.players[1] = p1index - 1;
            globals.players[2] = p2index - 1;
            
            if (p1index == 0 || p2index == 0)
                return;
            else
            {   
                p1.setText(playerTypes[p1index]);
                p2.setText(playerTypes[p2index]);
                
                main.gp.startGame();
                this.updatePlayerTurn();
            }
	    }
	    else if (e.getSource().equals(againButton))
	    {
		    restartMenu();
	    }
		else if (e.getSource().equals(autoChooseButton) && globals.players[globals.playerTurn] == 0)
		{
			int aiIndex = aiBox.getSelectedIndex();
		
			if (aiIndex == 0)
			    return;

            globals.aiPlayers[aiIndex].makeMove(new BoardStore(globals.gb), true);
            globals.playerTurn = (globals.playerTurn == 1) ? 2 : 1;
            globals.mp.updatePlayerTurn();

            if ((globals.players[globals.playerTurn] > 0) && (globals.winner == 0))
            {
                globals.aiPlayers[globals.players[globals.playerTurn]].makeMove(new BoardStore(globals.gb), true);
                globals.playerTurn = (globals.playerTurn == 1) ? 2 : 1;
                globals.mp.updatePlayerTurn();
            }
		}
	}
}
