import java.util.Vector;
import java.awt.*;

public class Peg
{
    public int status = 0;
    public Vector<Point> fenceDests = new Vector<Point>();

    public Peg()
    {}

    public void addFence(Point dest)
    {
        fenceDests.add(dest);
    }
}
