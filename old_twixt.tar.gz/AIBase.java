import java.awt.*;
import java.util.*;
import java.lang.Math;

public class AIBase
{
    int goalWeight;
    int blockWeight;
	Random randomGenerator = new Random();

    public class moveType
    {
		public Vector<Point> immediate = new Vector<Point>();
		public Vector<Point> setup = new Vector<Point>();

		public moveType()
		{}

		public void addAll(moveType second)
		{
			immediate.addAll(second.immediate);
			setup.addAll(second.setup);
		
			// Remove any duplicates	
//			for(int i = 0; i < immediate.size(); i++)
//				while(immediate.indexOf(immediate.elementAt(i)) != immediate.lastIndexOf(immediate.elementAt(i)))
//					immediate.remove(immediate.lastIndexOf(immediate.elementAt(i)));
			
//			for(int i = 0; i < setup.size(); i++)
//				while(setup.indexOf(setup.elementAt(i)) != setup.lastIndexOf(setup.elementAt(i)))
//					setup.remove(setup.lastIndexOf(setup.elementAt(i)));
		}
	}
	
	
	public AIBase()
	{
	    goalWeight = 1;
	    blockWeight = 1;
	}

    
    public static Comparator xcomp = new Comparator<Point>()
    {
        public int compare(Point a, Point b)
        {
            Vector<Point> pvec = globals.gb.playerPegs.get(2);
            int mean = 0;
            for (Point p : pvec)
                mean += p.x;
            mean = mean / pvec.size();
            
            int A = java.lang.Math.abs(mean-a.x);
            int B = java.lang.Math.abs(mean-b.x);
            
            if (A > B)
                return -1;
            else if (A < B)
                return 1;
            else
                return 0;
        }
    };

    public static Comparator ycomp = new Comparator<Point>()
    {
        public int compare(Point a, Point b)
        {      
            Vector<Point> pvec = globals.gb.playerPegs.get(1);
            int mean = 0;
            for (Point p : pvec)
                mean += p.y;
            mean = mean / pvec.size();
        
            int A = java.lang.Math.abs(mean-a.y);
            int B = java.lang.Math.abs(mean-b.y);
            
            if (A > B)
                return -1;
            else if (A < B)
                return 1;
            else
                return 0;
        }
    };
    
	public Vector<Point> forwardPrune(moveType[] mt, BoardStore bs, int turn)
	{
	    System.err.println("fwdprune called on aibase!?");
	    Vector<Point> allMoves = new Vector<Point>();
		
		if (mt[1].immediate.size() > 0)
		    return mt[1].immediate;
		
        for(int i = 0; i < mt.length; i++)
        {
		    if (mt[i].setup != null)
    		    allMoves.addAll(mt[i].setup);
		    if (mt[i].immediate != null)
    		    allMoves.addAll(mt[i].immediate);
        }
		
        if (allMoves.size() > 20)
        {
            Collections.shuffle(allMoves);
            allMoves.setSize(20);
        }

		return allMoves;
	}

	public moveType[] findMoves(BoardStore bs)
	{
		moveType currCollection[] = {new moveType(), new moveType(), new moveType()};
		
		// Gather Advancement Moves
		currCollection[0].addAll(type1AMoves(bs));
		currCollection[0].addAll(type2AMoves(bs));

		// Gather Blocking Moves
		currCollection[1].addAll(type1BMoves(bs));
		currCollection[1].addAll(type2BMoves(bs));

		// Gather Single Moves
		currCollection[2].addAll(typeGAMoves(bs));

		return currCollection;

	}

	public moveType typeGAMoves(BoardStore bs)
	{
		moveType currMoves = new moveType();
		Vector<Point> mine = bs.playerPegs.get(bs.playerTurn);
		Point offsetPoints[] = {new Point(1,2), new Point(-1, 2), new Point(1, -2), new Point(-1, -2), new Point(2,1), new Point(-2, 1), new Point(2, -1), new Point(-2, -1)};
		Point currPos, nextPos;

		for(int i = 0; i < mine.size(); i++)
		{
			currPos = mine.elementAt(i);
			for(int j = 0; j < 8; j++)
			{	
				nextPos = new Point(currPos.x + offsetPoints[j].x, currPos.y + offsetPoints[j].y);
				if(!bs.fenceCollision(currPos, nextPos)
				    && bs.pegs[nextPos.x][nextPos.y].status == 0 
				    &&  !(bs.isConnected(currPos, nextPos)))
				{
					currMoves.immediate.add(nextPos);
			    }
			}
		}
		return currMoves;
	}


	public Point setupPos(int i, Point pegPos, Point nextPegOffset, boolean horizOnly)
	{
		Point nextPos = new Point();
		// Get setup peg location
		if(i == 0)
		{
			nextPos.x = pegPos.x + nextPegOffset.x;
			nextPos.y =	pegPos.y + nextPegOffset.y;
		}
		else if (i == 1)
		{
			nextPos.x = pegPos.x - nextPegOffset.x;
			nextPos.y =	pegPos.y + nextPegOffset.y;
		}
		else if (i == 2)
		{
			if (horizOnly)
			{
				nextPos.x = pegPos.x + nextPegOffset.y;
				nextPos.y =	pegPos.y + nextPegOffset.x;

			}
			else
			{
				nextPos.x = pegPos.x + nextPegOffset.x;
				nextPos.y =	pegPos.y - nextPegOffset.y;
			}			
		}
		else
		{
			if (horizOnly)
			{
				nextPos.x = pegPos.x - nextPegOffset.y;
				nextPos.y =	pegPos.y - nextPegOffset.x;
			}
			else
			{
				nextPos.x = pegPos.x - nextPegOffset.x;
				nextPos.y =	pegPos.y - nextPegOffset.y;
			}	
		}
		return nextPos;
	}

	public Point[] immediatePos(int i, Point pegPos, Point nextPos, Point fencePegOffset, boolean horizOnly, boolean coign)
	{
		Point fencePos[] = {new Point(), new Point()};
		if (i == 0)
		{
			if (horizOnly)
			{
				fencePos[0].x = pegPos.x + fencePegOffset.x;
				fencePos[0].y = pegPos.y + fencePegOffset.y;
				fencePos[1].x = pegPos.x + fencePegOffset.x;
				fencePos[1].y = pegPos.y - fencePegOffset.y;
			}				
			else if(!coign)
			{
				fencePos[0].x = pegPos.x + fencePegOffset.x;
				fencePos[0].y = pegPos.y + fencePegOffset.y;
				fencePos[1].x = pegPos.x + fencePegOffset.y;
				fencePos[1].y = pegPos.y + fencePegOffset.x;
			}
			else
			{
				fencePos[0].x = pegPos.x + fencePegOffset.x;
				fencePos[0].y = pegPos.y + fencePegOffset.y;
				fencePos[1].x = nextPos.x - fencePegOffset.x;
				fencePos[1].y = nextPos.y - fencePegOffset.y;
			}
		}
		else if (i == 1)
		{
			if (horizOnly)
			{
				fencePos[0].x = pegPos.x - fencePegOffset.x;
				fencePos[0].y = pegPos.y + fencePegOffset.y;
				fencePos[1].x = pegPos.x - fencePegOffset.x;
				fencePos[1].y = pegPos.y - fencePegOffset.y;
			}				
			else if(!coign)
			{
				fencePos[0].x = pegPos.x - fencePegOffset.x;
				fencePos[0].y = pegPos.y + fencePegOffset.y;
				fencePos[1].x = pegPos.x - fencePegOffset.y;
				fencePos[1].y = pegPos.y + fencePegOffset.x;
			}
			else
			{
				fencePos[0].x = pegPos.x - fencePegOffset.x;
				fencePos[0].y = pegPos.y + fencePegOffset.y;
				fencePos[1].x = nextPos.x + fencePegOffset.x;
				fencePos[1].y = nextPos.y - fencePegOffset.y;
			}
		}
		else if (i == 2)
		{
			if (horizOnly)
			{
				fencePos[0].x = pegPos.x + fencePegOffset.y;
				fencePos[0].y = pegPos.y + fencePegOffset.x;
				fencePos[1].x = pegPos.x - fencePegOffset.y;
				fencePos[1].y = pegPos.y + fencePegOffset.x;
			}				
			else if(!coign)
			{
				fencePos[0].x = pegPos.x + fencePegOffset.x;
				fencePos[0].y = pegPos.y - fencePegOffset.y;
				fencePos[1].x = pegPos.x + fencePegOffset.y;
				fencePos[1].y = pegPos.y - fencePegOffset.x;
			}
			else
			{
				fencePos[0].x = pegPos.x + fencePegOffset.x;
				fencePos[0].y = pegPos.y - fencePegOffset.y;
				fencePos[1].x = nextPos.x - fencePegOffset.x;
				fencePos[1].y = nextPos.y + fencePegOffset.y;				
			}
		}
		else
		{
			if (horizOnly)
			{
				fencePos[0].x = pegPos.x + fencePegOffset.y;
				fencePos[0].y = pegPos.y - fencePegOffset.x;
				fencePos[1].x = pegPos.x - fencePegOffset.y;
				fencePos[1].y = pegPos.y - fencePegOffset.x;
			}				
			else if(!coign)
			{
				fencePos[0].x = pegPos.x - fencePegOffset.x;
				fencePos[0].y = pegPos.y - fencePegOffset.y;
				fencePos[1].x = pegPos.x - fencePegOffset.y;
				fencePos[1].y = pegPos.y - fencePegOffset.x;
			}
			else
			{
				fencePos[0].x = pegPos.x - fencePegOffset.x;
				fencePos[0].y = pegPos.y - fencePegOffset.y;
				fencePos[1].x = nextPos.x + fencePegOffset.x;
				fencePos[1].y = nextPos.y + fencePegOffset.y;
			}
		}
		return fencePos;
	}

	public moveType patternFinder(BoardStore bs, int pNumYou, int pNumOther, Point pegPos, Point nextPegOffset, Point fencePegOffset, boolean horizOnly, boolean coign)
	{
		moveType currMoves = new moveType();
		Point nextPos;
		Point fencePos[] = {null, null};
		boolean zeroOpen, oneOpen;	

randomGenerator.nextInt(24);
		
		for(int i = 0; i < 4; i++)
		{
			zeroOpen = false;
			oneOpen = false;
			nextPos = setupPos(i, pegPos, nextPegOffset, horizOnly);

			if (bs.isConnected(pegPos, nextPos))	
				continue;
            fencePos = immediatePos(i, pegPos, nextPos, fencePegOffset, horizOnly, coign);

			if(nextPos.x <= 23 && nextPos.y <= 23 && nextPos.x >= 0 && nextPos.y >= 0 &&
				!bs.fenceCollision(pegPos, nextPos) && bs.pegs[nextPos.x][nextPos.y].status == pNumYou)
			{
				// Add fences that are able to produce two fences
				if (fencePos[0].x <= 23 && fencePos[0].y <= 23 && fencePos[0].x >= 0 && fencePos[0].y >= 0 &&
						!bs.fenceCollision(pegPos, fencePos[0]) && !bs.fenceCollision(nextPos, fencePos[0]) &&
					 	bs.pegs[fencePos[0].x][fencePos[0].y].status == 0)
					zeroOpen = true;

					currMoves.immediate.add(fencePos[0]);
				
				if (fencePos[1].x <= 23 && fencePos[1].y <= 23 && fencePos[1].x >= 0 && fencePos[1].y >= 0 &&
						!bs.fenceCollision(pegPos, fencePos[1]) && !bs.fenceCollision(nextPos, fencePos[1]) &&
					 	bs.pegs[fencePos[1].x][fencePos[1].y].status == 0)
					oneOpen = true;

				if (zeroOpen && oneOpen)
					currMoves.immediate.add(fencePos[randomGenerator.nextInt(2)]);
				else if (zeroOpen)
					currMoves.immediate.add(fencePos[0]);
				else if (oneOpen)
					currMoves.immediate.add(fencePos[1]);
			}
	
			// Don't own peg in setup position, add to moves vector
			else if (nextPos.x <= 23 && nextPos.y <= 23 && nextPos.x >= 0 && nextPos.y >= 0 &&
					bs.pegs[nextPos.x][nextPos.y].status == 0 && 
					(bs.pegRange(bs.playerPegs.get(pNumOther),
					    quadMin(fencePos[0].x, fencePos[1].x, pegPos.x, nextPos.x)-1,  
					    quadMin(fencePos[0].y, fencePos[1].y, pegPos.y, nextPos.y)-1, 
					    quadMax(fencePos[0].x, fencePos[1].x, pegPos.x, nextPos.x)+1, 
					    quadMax(fencePos[0].y, fencePos[1].y, pegPos.y, nextPos.y)+1 ).isEmpty()))
			{
			    currMoves.setup.add(nextPos);
			}
		}

		return currMoves;
	}

	// Safe Moves
	public moveType type1AMoves(BoardStore bs)
	{
		moveType currMoves = new moveType();
		Vector<Point> mine = bs.playerPegs.get(bs.playerTurn);
		int nextPlayer = (bs.playerTurn == 1) ? 2 : 1;
		Vector<Point> yours = bs.playerPegs.get(nextPlayer);

		// 1-1 Short
		for(int i = 0; i < mine.size(); i++)
			currMoves.addAll(patternFinder(bs, bs.playerTurn, nextPlayer, mine.elementAt(i), new Point(1,1), new Point(-1,2), false, false));

		// 2-0 Mesh
		for(int i = 0; i < mine.size(); i++)
			currMoves.addAll(patternFinder(bs, bs.playerTurn, nextPlayer, mine.elementAt(i), new Point(2,0), new Point(1,2), true, false));

		// 3-1 Coign - Horizontal
		for(int i = 0; i < mine.size(); i++)
			currMoves.addAll(patternFinder(bs, bs.playerTurn, nextPlayer, mine.elementAt(i), new Point(3,1), new Point(1,2), false, true));

		// 1-3 Coign - Vertical
		for(int i = 0; i < mine.size(); i++)
			currMoves.addAll(patternFinder(bs, bs.playerTurn, nextPlayer, mine.elementAt(i), new Point(1,3), new Point(-1,2), false, true));

		// 3-3 Tilt
		for(int i = 0; i < mine.size(); i++)
			currMoves.addAll(patternFinder(bs, bs.playerTurn, nextPlayer, mine.elementAt(i), new Point(3,3), new Point(1,2), false, false));
	
		// 4-0 Beam
		for(int i = 0; i < mine.size(); i++)
			currMoves.addAll(patternFinder(bs, bs.playerTurn, nextPlayer, mine.elementAt(i), new Point(4,0), new Point(2,1), true, false));

		return currMoves;
	}


	public moveType type2AMoves(BoardStore bs)
	{
		moveType currMoves = new moveType();

		// 3-0
	
		// 4-2

		// 4-3

		// 5-0
	
		// 5-2
	
		// 5-4

		// 6-1
	
		// 7-3
	
		return currMoves;
	}

	public moveType type1BMoves(BoardStore bs)
	{
		moveType currMoves = new moveType();
		moveType enemyMoves;
		Vector<Point> mine = bs.playerPegs.get(bs.playerTurn);
		int nextPlayer = (bs.playerTurn == 1) ? 2 : 1;
		Vector<Point> yours = bs.playerPegs.get(nextPlayer);
		Vector<Point> mineSubset;
		Point currPoint;
		Point blockPoint;
		Point enemyPoint, enemyPointPos;
		Point offsetPoints[] = {new Point(1,2), new Point(-1, 2), new Point(1, -2), new Point(-1, -2), new Point(2,1), new Point(-2, 1), new Point(2, -1), new Point(-2, -1)};
		int blockCnt;
		boolean hasFences;
		// 3-1

		// 4-0 and 3-3 Combined
		for(int i = 0; i < yours.size(); i++)
		{

			enemyPoint = yours.elementAt(i);
			hasFences = !bs.pegs[enemyPoint.x][enemyPoint.y].fenceDests.isEmpty();

			// Determine if enemy has any immediate moves, if non-empty, proceed to next step
			enemyMoves = patternFinder(bs, nextPlayer, bs.playerTurn,  enemyPoint, new Point(4,0), new Point(2,1), true, false);
			enemyMoves.addAll(patternFinder(bs, nextPlayer, bs.playerTurn, enemyPoint, new Point(3,3), new Point(1,2), false, false));
			enemyMoves.addAll(patternFinder(bs, nextPlayer, bs.playerTurn, enemyPoint, new Point(3,1), new Point(1,2), false, true));
			if (enemyMoves.immediate.isEmpty())				
			{
				// Enemy Horizontal		
				if(!hasFences)
				{		
				    if (bs.playerTurn == 1)
				    {
    			        if (!BoardStore.outOfBounds(new Point(enemyPoint.x, enemyPoint.y-1))
    			            && !BoardStore.outOfBounds(new Point(enemyPoint.x, enemyPoint.y+1))
       			            && (bs.pegs[enemyPoint.x][enemyPoint.y-1].status == 0)
    			            && (bs.pegs[enemyPoint.x][enemyPoint.y+1].status == 0))
    			        {
					        if (enemyPoint.y <= 11)
						        currMoves.setup.add(new Point(enemyPoint.x, enemyPoint.y+1));
					        else
						        currMoves.setup.add(new Point(enemyPoint.x, enemyPoint.y-1));
                        }
    /*                    else
                        {
                            if ((!BoardStore.outOfBounds(new Point(enemyPoint.x, enemyPoint.y-1)))
                                && (bs.pegs[enemyPoint.x][enemyPoint.y-1].status == 0))
	    
						        currMoves.setup.add(new Point(enemyPoint.x, enemyPoint.y-1));

                            if ((!BoardStore.outOfBounds(new Point(enemyPoint.x, enemyPoint.y+1)))
                                && (bs.pegs[enemyPoint.x][enemyPoint.y+1].status == 0))
	
						        currMoves.setup.add(new Point(enemyPoint.x, enemyPoint.y+1));
                        }
		*/		    }
				    // Enemy Vertical
				    else
				    {
    			        if (!BoardStore.outOfBounds(new Point(enemyPoint.x-1, enemyPoint.y))
    			            && !BoardStore.outOfBounds(new Point(enemyPoint.x+1, enemyPoint.y))
       			            && (bs.pegs[enemyPoint.x-1][enemyPoint.y].status == 0)
    			            && (bs.pegs[enemyPoint.x+1][enemyPoint.y].status == 0))
    			        {
					        if (enemyPoint.y <= 11)
						        currMoves.setup.add(new Point(enemyPoint.x+1, enemyPoint.y));
					        else
						        currMoves.setup.add(new Point(enemyPoint.x-1, enemyPoint.y));
                        }
       /*                 else
                        {
                            if ((!BoardStore.outOfBounds(new Point(enemyPoint.x-1, enemyPoint.y)))
                                && (bs.pegs[enemyPoint.x-1][enemyPoint.y].status == 0))
	    
						        currMoves.setup.add(new Point(enemyPoint.x-1, enemyPoint.y));

                            if ((!BoardStore.outOfBounds(new Point(enemyPoint.x+1, enemyPoint.y)))
                                && (bs.pegs[enemyPoint.x+1][enemyPoint.y].status == 0))
	
						        currMoves.setup.add(new Point(enemyPoint.x+1, enemyPoint.y));
                        }
		*/		    }
				}
				continue;
			}
			else
			{
			    if(!hasFences)
			    {
				    for (int n = 0; n < enemyMoves.immediate.size(); n++)
				    {
					    enemyPointPos = enemyMoves.immediate.elementAt(n);	
					    // Enemy Horizontal				
					    if (bs.playerTurn == 1)
					    {
	       			        if (!BoardStore.outOfBounds(new Point(enemyPoint.x-1, enemyPoint.y))
        			            && !BoardStore.outOfBounds(new Point(enemyPoint.x+1, enemyPoint.y))
           			            && (bs.pegs[enemyPoint.x-1][enemyPoint.y].status == 0)
        			            && (bs.pegs[enemyPoint.x+1][enemyPoint.y].status == 0))
        			        {
						        if (enemyPoint.y <= 11 && enemyPoint.x > 2 && enemyPoint.x < 22 && enemyPointPos.y < enemyPoint.y)
							        currMoves.setup.add(new Point(enemyPoint.x, enemyPoint.y+1));
						        else if (enemyPoint.x > 2 && enemyPoint.x < 22)
							        currMoves.setup.add(new Point(enemyPoint.x, enemyPoint.y-1));
					        }
					    }
					    // Enemy Vertical
					    else
					    {
        			        if (!BoardStore.outOfBounds(new Point(enemyPoint.x-1, enemyPoint.y))
        			            && !BoardStore.outOfBounds(new Point(enemyPoint.x+1, enemyPoint.y))
           			            && (bs.pegs[enemyPoint.x-1][enemyPoint.y].status == 0)
        			            && (bs.pegs[enemyPoint.x+1][enemyPoint.y].status == 0))
    			            {
						        if (enemyPoint.x <= 11 && enemyPoint.y > 2 && enemyPoint.y < 22 && enemyPointPos.x < enemyPoint.x)
							        currMoves.setup.add(new Point(enemyPoint.x+1, enemyPoint.y));
						        else if (enemyPoint.y > 2 && enemyPoint.y < 22)
							        currMoves.setup.add(new Point(enemyPoint.x-1, enemyPoint.y));
                            }
					    }
				    }
		        }
			}


			// Get all pegs located around peg in question, if non-empty, proceed to next step
			mineSubset = bs.pegRange(mine, enemyPoint.x-2, enemyPoint.y-2, enemyPoint.x+2, enemyPoint.y+2);
			if (mineSubset.isEmpty())
				continue;

			// Determine if any moves would block two of the opponents moves (indicates successful block), if so, add move as a possible move
			for (int j = 0; j < mineSubset.size(); j++)
			{
				currPoint = mineSubset.elementAt(j);

				for (int k = 0; k < 8; k++)
				{
					blockCnt = 0;
					blockPoint = new Point(currPoint.x + offsetPoints[k].x, currPoint.y + offsetPoints[k].y);
					if(bs.placePeg(blockPoint.x, blockPoint.y))
					{
						for (int n = 0; n < enemyMoves.immediate.size(); n++)
						{	
							if (bs.fenceCollision(enemyPoint, enemyMoves.immediate.elementAt(n)))
							{
								blockCnt++;
							}

						}
						bs.removePeg(blockPoint.x, blockPoint.y);

						if (blockCnt >= 2 && !hasFences)
						{
			    			currMoves.immediate.add(blockPoint);
						}							
					}
				}
			}
		}

		return currMoves;
	}

	public moveType type2BMoves(BoardStore bs)
	{
		moveType currMoves = new moveType();
	
		// 4-3

		// 5-0
	
		// 6-1

		// 7-3
	
		return currMoves;
	}

	public void makeMove(BoardStore bs, boolean realBoard)
    {
        try{
            Thread.sleep(500);
        } catch (Exception ex)
        {}
        
        int x = 0;
        int y = 0;

        boolean placed = false;
				while (!placed)
        {
			   			x = randomGenerator.nextInt(24);
              y = randomGenerator.nextInt(24);
              
              if (realBoard)
                  placed = globals.gb.placePeg(x, y);
              else
                  placed = bs.placePeg(x, y);
        }
        return;
    }
	
	public int evalBoard(int playerTurn, BoardStore bs)
    {
		int p1Score = evalBoardForP1(bs);
		int p2Score = evalBoardForP2(bs);

		//System.err.println("p1Score: " + p1Score + ", p2Score: " + p2Score);

        if (playerTurn == 1)
        	return goalWeight*p1Score - blockWeight*p2Score;
		else if (playerTurn == 2)
        	return goalWeight*p2Score - blockWeight*p1Score;
        else
            return -1000;
    }

    public int evalBoardForP1(BoardStore bs)
    {
        int maxrange = 0;
        int maxconn = 0;
        int maxnear = 0;
        boolean visited[][] = new boolean[24][24];
        for (int i = 0; i < 24; i++)
            for (int j = 0; j < 24; j++)
                visited[i][j] = false;
        
        Vector<Point> P1 = bs.playerPegs.get(1);
        Vector<Point> P2 = bs.playerPegs.get(2);
        
        for (int i = 0; i < P1.size(); i++)
        {
            Vector<Point> q = new Vector<Point>();
            Point peg = P1.elementAt(i);
            if (!visited[peg.x][peg.y])
            {
                q.add(peg);
                int miny = 24;
                int maxy = -1;
                int nearCount = 0;
                int connCount = 0;
                while (!q.isEmpty())
                {
                    Point p = q.remove(0);
                    if (!visited[p.x][p.y])
                    {
                        visited[p.x][p.y] = true;
                        if (bs.pegRange(P2, p.x-1, p.y-1, p.x+1, p.y).size() != 0)
                            for(int k = -2; k <= 2; k++)
                            {
							    if ((p.y < miny) && (bs.pegRange(P2, p.x-1+3*k, 0, p.x+1+3*k, p.y-Math.abs(k)).size() <= 1))
                              	  miny = p.y;
                            }

                        if (bs.pegRange(P2, p.x-1, p.y, p.x+1, p.y+1).size() != 0)
                            for(int k = -2; k <= 2; k++)
                            {
                            	if ((p.y > maxy) && (bs.pegRange(P2, p.x-1+3*k, p.y+Math.abs(k), p.x+1+3*k, 23).size() <= 1))
                              	  maxy = p.y;
                            }

                        Vector<Point> adj = bs.pegs[p.x][p.y].fenceDests;
                        for (int j = 0; j < adj.size(); j++)
                        {
                            connCount++;
                            q.add(adj.elementAt(j));
                        }   
                        Vector<Point> near = bs.pegRange(P1, p.x-4, p.y-4, p.x+4, p.y+4);
                        for (int j = 0; j < near.size(); j++)
                        {
                            Point n = near.elementAt(j);
                            if ((!adj.contains(n))
                                && bs.pegRange(P2, 
                                    java.lang.Math.min(n.x, p.x),
                                    java.lang.Math.min(n.y, p.y),
                                    java.lang.Math.max(n.x, p.x),
                                    java.lang.Math.max(n.y, p.y)).size() == 0)
                            {
                                nearCount++;
                                q.add(n);
                            }    
                        }
                    }
                }
                if (maxy-miny > maxrange)
                {
                    maxrange = maxy-miny;
                    maxconn = connCount;
                    maxnear = nearCount;
                }
            }
        }
        
        
        int value;
        if (maxrange == 23)
            value = 1000;
        else if (maxrange >= 22)
            value = 100;
        else if (maxrange >= 18)
            value = 50;
        else
            value = maxrange;

        return value * maxconn / (maxnear + 1);
    }

public int evalBoardForP2(BoardStore bs)
{
    int maxrange = 0;
    boolean visited[][] = new boolean[24][24];
    for (int i = 0; i < 24; i++)
        for (int j = 0; j < 24; j++)
            visited[i][j] = false;
    
    Vector<Point> P1 = bs.playerPegs.get(1);
    Vector<Point> P2 = bs.playerPegs.get(2);
    
    for (int i = 0; i < P2.size(); i++)
    {
        Vector<Point> q = new Vector<Point>();
        Point peg = P2.elementAt(i);
        if (!visited[peg.x][peg.y])
        {
            q.add(peg);
            int minx = 24;
            int maxx = -1;
            while (!q.isEmpty())
            {
                Point p = q.remove(0);
                if (!visited[p.x][p.y])
                {
                    visited[p.x][p.y] = true;
                    
                    int rangehi = bs.pegRange(P1, p.x, p.y-1, 23, p.y+1).size();
                    int rangelo = bs.pegRange(P1, 0, p.y-1, p.x, p.y+1).size();
                    if ((p.x < minx) && (rangelo <= 1))
                        minx = p.x;
                    if ((p.x > maxx) && (rangehi <= 1))
                        maxx = p.x;
                        
                    Vector<Point> adj = bs.pegs[p.x][p.y].fenceDests;
                    for (int j = 0; j < adj.size(); j++)
                        q.add(adj.elementAt(j));
                        
                    Vector<Point> near = bs.pegRange(P2, p.x-4, p.y-4, p.x+4, p.y+4);
                    for (int j = 0; j < near.size(); j++)
                    {
                        Point n = near.elementAt(j);
                        if ((!adj.contains(n))
                            && bs.pegRange(P1, 
                                java.lang.Math.min(n.x, p.x),
                                java.lang.Math.min(n.y, p.y),
                                java.lang.Math.max(n.x, p.x),
                                java.lang.Math.max(n.y, p.y)).size() == 0)
                        {
                            q.add(n);
                        }    
                    }
                }
            }
            if (maxx-minx > maxrange)
                maxrange = maxx - minx;
        }
    }
    
    if (maxrange == 23)
        return 10000;
    if (maxrange >= 22)
        return 100;
    if (maxrange >= 18)
        return 50;
    return maxrange;
}
	
	
	int quadMax(int a, int b, int c, int d)
	{
		int x = java.lang.Math.max(a, b);
		int y = java.lang.Math.max(c, d);
		return java.lang.Math.max(x, y);
	}

	int quadMin(int a, int b, int c, int d)
	{
		int x = java.lang.Math.min(a, b);
		int y = java.lang.Math.min(c, d);
		return java.lang.Math.min(x, y);
	}
}
