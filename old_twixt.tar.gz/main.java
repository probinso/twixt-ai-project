import javax.swing.*;

public class main extends JFrame
{
    public static GamePanel gp;

	public static void main(String[] args) 
	{
		JFrame window = new JFrame();
		window.setTitle("Twixt");
		window.setLocation(0, 0);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(920, 755);
        window.setResizable(true);
		window.setVisible(true);

        gp = new GamePanel();
        window.add(gp);
        gp.begin();
	}
}
