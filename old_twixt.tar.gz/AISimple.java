import java.awt.*;
import java.util.*;

public class AISimple extends AIBase
{
    public AISimple(int gWeight, int bWeight)
    {
	    goalWeight = gWeight;
	    blockWeight = bWeight;
    }

	public void makeMove(BoardStore bs, boolean realBoard)
    {
        int x = 0;
        int y = 0;
        Point currPoint = new Point(0,0);

        if (bs.numUsedPegs < 2)
        {
            x = randomGenerator.nextInt(12) + 6;
            y = (randomGenerator.nextInt(2) == 1) ? 3 : 20;

            if (globals.playerTurn == 2)
            {
                int a = x;
                x = y;
                y = a;   
            }
            currPoint = new Point(x, y);
        }
        else
        {
            abtree ab = new abtree();
            currPoint = ab.ABsearch(bs, 3, this);
        }

        boolean placed;

        if (realBoard)
            placed = globals.gb.placePeg(currPoint.x, currPoint.y);
        else
            placed = bs.placePeg(currPoint.x, currPoint.y);
        
        if (placed)
            return;

        moveType myMoves[] = findMoves(bs);
        Vector<Point> prunedMoves = forwardPrune(myMoves, bs, bs.playerTurn);
        while (!placed)
        {
            if (!prunedMoves.isEmpty())
            {
                currPoint = prunedMoves.remove(0);
                x = currPoint.x;
                y = currPoint.y;					
            }
            else
            {
                x = randomGenerator.nextInt(24);
                y = randomGenerator.nextInt(24);
            }
            if (realBoard)
                placed = globals.gb.placePeg(x, y);
            else
                placed = bs.placePeg(x, y);
        }   
        return;
    }

    public moveType[] findMoves(BoardStore bs)
	{
		moveType currCollection[] = {new moveType()};
		
		// Gather Single Moves
		currCollection[0].addAll(typeGAMoves(bs));

		return currCollection;

	}

    public Vector<Point> forwardPrune(moveType[] mt, BoardStore bs, int turn)
	{
	    Vector<Point> allMoves = new Vector<Point>();
		
		boolean added[][] = new boolean[24][24];
		for (int i = 0; i < 24; i++)
			for (int j = 0; j < 24; j++)
			    added[i][j] = false;

        /* Adding immediate moves */
        Vector<Point> immediate = new Vector<Point>();
		immediate.addAll(mt[0].immediate);

		if (turn == 1)
    		Collections.sort(immediate, ycomp);
        else
            Collections.sort(immediate, xcomp);

        if (immediate.size() > 30)
            immediate.setSize(30);

        allMoves.addAll(immediate);

		int x, y;
		Vector<Point> unique = new Vector<Point>(allMoves);
		for(Point p : allMoves)
		{
			x = p.x;
			y = p.y;
            
            if (added[x][y])
                unique.remove(p);
            else
            {
                added[x][y] = true;
			    if (bs.playerTurn == 1)
			    {	
				    if (x == 0 || x == 23)
	    		        unique.remove(p);
			    }
			    else if (bs.playerTurn == 2)
			    {	
				    if (y == 0 || y == 23)
    			        unique.remove(p);
			    }
            }			
		}
		return allMoves;
	}
    
    public int evalBoardForP1(BoardStore bs)
    {
        int maxrange = 0;
        boolean visited[][] = new boolean[24][24];
        for (int i = 0; i < 24; i++)
            for (int j = 0; j < 24; j++)
                visited[i][j] = false;
        
        Vector<Point> P1 = bs.playerPegs.get(1);
        
        for (int i = 0; i < P1.size(); i++)
        {
            Vector<Point> q = new Vector<Point>();
            Point peg = P1.elementAt(i);
            if (!visited[peg.x][peg.y])
            {
                q.add(peg);
                int miny = 24;
                int maxy = -1;
                while (!q.isEmpty())
                {
                    Point p = q.remove(0);
                    if (!visited[p.x][p.y])
                    {
                        visited[p.x][p.y] = true;

                        if (p.y > maxy)
                            maxy = p.y;

                        if (p.y < miny)
                            miny = p.y;

                        q.addAll(bs.pegs[p.x][p.y].fenceDests);
                    }
                }
                if (maxy-miny > maxrange)
                {
                    maxrange = maxy-miny;
                }
            }
        }
        
        int value;
        if (maxrange == 23)
            return 1000;
        else if (maxrange >= 22)
            return 100;
        else if (maxrange >= 18)
            return 50;
        else
            return maxrange;
    }

    public int evalBoardForP2(BoardStore bs)
    {
        int maxrange = 0;
        boolean visited[][] = new boolean[24][24];
        for (int i = 0; i < 24; i++)
            for (int j = 0; j < 24; j++)
                visited[i][j] = false;
        
        Vector<Point> P2 = bs.playerPegs.get(1);
        
        for (int i = 0; i < P2.size(); i++)
        {
            Vector<Point> q = new Vector<Point>();
            Point peg = P2.elementAt(i);
            if (!visited[peg.x][peg.y])
            {
                q.add(peg);
                int minx = 24;
                int maxx = -1;
                while (!q.isEmpty())
                {
                    Point p = q.remove(0);
                    if (!visited[p.x][p.y])
                    {
                        visited[p.x][p.y] = true;
                        
                        if (p.x > maxx)
                            maxx = p.x;

                        if (p.x < minx)
                            minx = p.x;

                        q.addAll(bs.pegs[p.x][p.y].fenceDests);
                    }
                }
                if (maxx-minx > maxrange)
                {
                    maxrange = maxx-minx;
                }
            }
        }
        
        int value;
        if (maxrange == 23)
            return 1000;
        else if (maxrange >= 22)
            return 100;
        else if (maxrange >= 18)
            return 50;
        else
            return maxrange;
    }
}
