import java.awt.*;
import java.util.Vector;

public class main 
{   
    
    public static void main(String[] args){
	Vector<boardFunc> myFunc = new Vector<boardFunc>();
	
	for (int i = 0; i < 3; i++)
	    for (int j = 0; j < 3; j++){
		final int x = i;
		final int y = j;
		myFunc.add(new boardFunc(){
			public Boolean isValid(Board B){return B.canPlace(new Point(x,y));}
			public Board function(Board B){return B.Copy().Place(new Point(x,y));}
		    });
	    }
	Board B = new Board();

	State S = new State(B,myFunc);

	
	int x;
	x = 1;
	System.err.println("------------ "+x+"  -------------");
	/**/
	S = abtree.ABsearch(new State(B,myFunc),x);
	S.print();
	for (int i = 0; i < 8; i++){
	    S = abtree.ABsearch(S,x);
	    S.print();
	}

	/**/	
	x = 2;
	/**/
	System.err.println("------------ "+x+"  -------------");
	S = abtree.ABsearch(new State(B,myFunc),x);
	S.print();
	for (int i = 0; i < 8; i++){
	    S = abtree.ABsearch(S,x);
	    S.print();
	}

	/**/	

	x = 3;
	/**/
	System.err.println("------------ "+x+"  -------------");
	S = abtree.ABsearch(new State(B,myFunc),x);
	S.print();
	for (int i = 0; i < 8; i++){
	    S = abtree.ABsearch(S,x);
	    S.print();
	}

	/**/	
	x = 4;

	System.err.println("------------ "+x+"  -------------");

	S = abtree.ABsearch(new State(B,myFunc),x);
	S.print();
	for (int i = 0; i < 8; i++){
	    S = abtree.ABsearch(S,x);
	    S.print();
	}
	/**/

	
	return;
    }
}