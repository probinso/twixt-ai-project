public interface boardFunc{
    /*
      boardFunc interface provides general operations
      on boards
    */
    public Boolean isValid(Board param);
    /*should return if the board function is a valid option*/
    
    public Board function(Board param);
    /*should return board iff isValid*/
}

