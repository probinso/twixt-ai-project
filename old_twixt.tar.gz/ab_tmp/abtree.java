import java.awt.*;

public class abtree{

    private static int max(int a, int b){return (a<b)?b:a;}
    private static int min(int a, int b){return (a<b)?a:b;}
    
    private static Board.Cell myTurn = Board.Cell.E;
    
    private static final int I_FIRST = -2147483648;
    private static final int I_LAST  =  2147483647;


    //private static int alpha,beta;
    
    public static State ABsearch(State S,int depth){
	myTurn = S.Self.NextTurn;
	S.score = -100;
	S = maxValue(S,depth,I_FIRST,I_LAST);
	System.err.println("\n IT IS THE TURN OF " +myTurn +" with a score of " + S.score);

	return S;
    }
    
    public static State maxValue(State S,int depth,int alpha, int beta){
	//	S.score = beta;
	State Ret = S;
	
	if (depth*S.validFuncs.size()==0){
	    Ret.score = Ret.Eval(myTurn);
	    return Ret;
	}
        
	for (int i = 0; i < S.validFuncs.size(); i++){
	    //System.err.print("*");
	    State Tmp = new State(S.validFuncs.elementAt(i).function(S.Self.Copy()),S.validFuncs);
	    
	    State Get = minValue(Tmp,depth-1,alpha,beta);
	    Tmp.score = Get.score;
	    
	    if (alpha < Get.score){
		Ret = Tmp;
		alpha = Ret.score;
	    }
	    //	System.err.print("["+Get.score+"]");
	    if (alpha >= beta){
		Ret.score = beta;
		return Ret;
	    }
	    
	}
	return Ret;
    }
    
    public static State minValue(State S,int depth,int alpha, int beta){
	//	S.score = alpha;
	State Ret = S;
	
	if (depth*S.validFuncs.size()==0){
	    Ret.score = Ret.Eval(myTurn);
	    return Ret;
	}
	
	for (int i = 0; i < S.validFuncs.size(); i++){
	    
	    State Tmp = new State(S.validFuncs.elementAt(i).function(S.Self.Copy()),S.validFuncs);
	    //	    System.err.print(".");
	    
	    State Get = maxValue(Tmp,depth-1,alpha,beta);
	    Tmp.score = Get.score;
	    
	    if (Get.score<beta){
		Ret = Tmp;
		beta = Ret.score;
		// System.err.print("beta : "+beta+", score : "+Ret.score);
	    }
	    //System.err.print("("+Get.score+")");
	    if (beta <= alpha){
		Ret.score = alpha;
		return Ret;
	    }
	}

	return Ret;
    }
}