import java.awt.*;
import java.util.Vector;


public class State{

    public Board Self; 

    public int score = -200;
    
    /*
    private static final int I_FIRST = -2147483648;
    private static final int I_LAST  =  2147483647;

    public int alpha = I_FIRST;
    public int beta  = I_LAST;
    */
    
    public Vector<boardFunc> validFuncs = new Vector<boardFunc>();

    public void print(){
	Self.print();
	return;
    }
    /**/
    public State(Board B, Vector<boardFunc> Ops){
	// State does not copy board
	// It only stores it by reference
	this.Self = B;
	for (int i = 0; i < Ops.size(); i++)
	    if (Ops.elementAt(i).isValid(this.Self))
		this.validFuncs.add(Ops.elementAt(i));
    }
    public int Eval(Board.Cell Me){
	return this.Self.Eval(Me);
    }
    /**/	
}