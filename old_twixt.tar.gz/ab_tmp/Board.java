import java.awt.*;
import java.util.Vector;

public class Board{	
    
    public Cell NextTurn;
    
    public enum Cell{ X , O , E }
    
    private Cell Self[][] = new Cell[3][3];
    
    
    public Board(){
	for (int i = 0; i < 3; i++)
	    for (int j = 0; j < 3; j++){
		this.Self[i][j] = Cell.E;
	    }
	this.NextTurn = Cell.X;
    }

    public Board Copy(){
	
	Board B = new Board();
	for (int i = 0; i < 3; i++)
	    for (int j = 0; j < 3; j++)
		B.Self[i][j] = this.Self[i][j];
	
	B.NextTurn = this.NextTurn;
	return B;
    }

    /**/

    public Boolean canPlace(Point P){
	return (this.Self[P.x][P.y] == Cell.E);
    }
    
    public Board Place(Point P){
	this.Self[P.x][P.y] = this.NextTurn;
	this.NextTurn = (this.NextTurn == Cell.X)?Cell.O:Cell.X;
	return this;
    }
    
    public void print(){
	
	for (int i = 0; i < 3; i++){
	    for (int j = 0;j < 3; j++){
		if (this.Self[i][j] == Cell.E)
		    System.err.print(" ");
		else
		    System.err.print(this.Self[i][j]);
		if (j < 2) System.err.print("|");
	    }
	    if (i < 2)System.err.println("\n-----");

	}
	System.err.println("\n");
	
    }

    public int Eval(Cell Me){
	
	int X3 = 0;
	int X2 = 0;
	int X1 = 0;
	int O3 = 0;
	int O2 = 0;
	int O1 = 0;
	
	
	int x = 0; 
	int o = 0;
	for (int i = 0; i < 3; i++){
	    // row
	    x = 0;
	    o = 0;
	    for (int j = 0; j < 3; j++){
		if (Self[i][j] == Cell.X)x++;
		else if (Self[i][j] == Cell.O)o++;
	    }
	    if ((x==3) && (o==0)) X3++;
	    if ((x==0) && (o==3)) O3++;
	    if ((x==2) && (o==0)) X2++;
	    if ((x==0) && (o==2)) O2++;
	    if ((x==1) && (o==0)) X1++;
	    if ((x==0) && (o==1)) O1++;
	}
	
	x = 0;
	o = 0;
	for (int i = 0; i < 3; i++){
	    // collumn
	    x = 0;
	    o = 0;
	    for (int j = 0; j < 3; j++)
		if (Self[j][i] == Cell.X) x++;
		else if (Self[j][i] == Cell.O) o++;
	    if ((x==3) && (o==0)) X3++;
	    if ((x==0) && (o==3)) O3++;
	    if ((x==2) && (o==0)) X2++;
	    if ((x==0) && (o==2)) O2++;
	    if ((x==1) && (o==0)) X1++;
	    if ((x==0) && (o==1)) O1++;
	}
	
	x = 0; 
	o = 0;
	//diag l->r
	for (int i = 0; i < 3; i++)
	    if (Self[i][i]==Cell.X)x++;
	    else if (Self[i][i] == Cell.O) o++;
	if ((x==3) && (o==0)) X3++;
	if ((x==0) && (o==3)) O3++;
	if ((x==2) && (o==0)) X2++;
	if ((x==0) && (o==2)) O2++;
	if ((x==1) && (o==0)) X1++;
	if ((x==0) && (o==1)) O1++;
	
	
	x = 0; 
	o = 0;
	//diag r->l
	for (int i = 0; i < 3; i++)
	    if (Self[2-i][i]==Cell.X)x++;
	    else if (Self[2-i][i] == Cell.O) o++;
	if ((x==3) && (o==0)) X3++;
	if ((x==0) && (o==3)) O3++;
	if ((x==2) && (o==0)) X2++;
	if ((x==0) && (o==2)) O2++;
	if ((x==1) && (o==0)) X1++;
	if ((x==0) && (o==1)) O1++;
	
	int Xs = 900*X3+3*X2+X1;
	int Os = 900*O3+3*O2+O1;
	int ret = (Me==Cell.X)?Xs-Os:Os-Xs;

	//System.err.println("It is "+ Me +", Score for Board :" + ret);
	//this.print();
	
	//System.err.println("-----------------");
	return ret;
	
    }
    
}

