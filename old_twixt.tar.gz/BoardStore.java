import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.ArrayList;
import java.lang.Math;

public class BoardStore
{    

    public Peg[][] pegs = new Peg[24][24];
    public int numUsedPegs = 0;
    public ArrayList<Vector<Point>> playerPegs = new ArrayList<Vector<Point>>(3);

    // Next Turn ;;

    public int playerTurn = 0;

    
    public BoardStore(GameBoard G)
    {
	    pegs = new Peg[24][24];
	    numUsedPegs = G.numUsedPegs;
	    playerPegs = G.copyPlayerPegs();

        for (int i = 0; i < 24; i++)
	        for(int j = 0; j < 24;j++){
		        pegs[i][j] = new Peg();
		        pegs[i][j].status = G.pegs[i][j].status;
		        for (int k = 0; k < G.pegs[i][j].fenceDests.size(); k++)
		            pegs[i][j].addFence(new Point(G.pegs[i][j].fenceDests.elementAt(k).x,
						          G.pegs[i][j].fenceDests.elementAt(k).y));
    }

	numUsedPegs = G.numUsedPegs;

	playerTurn = globals.playerTurn;
	
    }
    
    public BoardStore(){
	pegs = new Peg[24][24];
	numUsedPegs = 0;
	playerPegs = new ArrayList<Vector<Point>>(3);
	playerTurn = 0;
    }
    

    // untested.
    private ArrayList<Vector<Point>> copyPlayerPegs ()
    {
        Vector<Point> v1 = new Vector<Point> ();
        Vector<Point> v2 = new Vector<Point> ();
        
        Vector<Point> p1 = playerPegs.get(1);
        Vector<Point> p2 = playerPegs.get(2);
        
        for (Point p : p1)
            v1.add(new Point(p.x, p.y));

        for (Point p : p2)
            v2.add(new Point(p.x, p.y));
            
        ArrayList<Vector<Point>> returnPlayerPegs = new ArrayList<Vector<Point>>(3);
        returnPlayerPegs.add(new Vector<Point>());
        returnPlayerPegs.add(v1);
        returnPlayerPegs.add(v2);
        
        return returnPlayerPegs;
    }

    public BoardStore Copy(){
	BoardStore B = new BoardStore();
	
	for (int i = 0; i < 24; i++)
	    for(int j = 0; j < 24;j++){
		B.pegs[i][j] = new Peg();
		B.pegs[i][j].status = this.pegs[i][j].status;
		for (int k = 0; k < this.pegs[i][j].fenceDests.size(); k++)
		    B.pegs[i][j].addFence(new Point(this.pegs[i][j].fenceDests.elementAt(k).x,
						    this.pegs[i][j].fenceDests.elementAt(k).y));
	      
	    }

	B.numUsedPegs = this.numUsedPegs;

	B.playerPegs = this.copyPlayerPegs();
	B.playerTurn = this.playerTurn;
	return B;	
    }

    /* Here be stubs and additions */
    public int Eval(int player, AIBase ai)
    {
    	return ai.evalBoard(player,this);
    }
    
    
    public boolean isConnected(Point P1, Point P2)
	{
		if (outOfBounds(P1) || outOfBounds(P2))
			return true;
        boolean visited[][] = new boolean[24][24];
        for (int i = 0; i < 24; i++)
            for (int j = 0; j < 24; j++)
                visited[i][j] = false;

        Vector<Point> q = pegs[P1.x][P1.y].fenceDests;

		Point currPoint;
		while(!q.isEmpty())
		{
			currPoint = q.remove(0);
			if ((currPoint.x == P2.x) && (currPoint.y == P2.y))
				return true;

			if (!visited[currPoint.x][currPoint.y])
			{
				visited[currPoint.x][currPoint.y] = true; 
				q.addAll(pegs[currPoint.x][currPoint.y].fenceDests);
			}
		}
		return false;
	}
    
    public Vector<Point> pegRange(Vector<Point> vec, int low_x, int low_y, int high_x, int high_y)
    {
	Vector<Point> filteredVec = new Vector<Point>();
	Point pnt;
	
	int vLen = vec.size();
	
	for(int i = 0; i < vLen; i++)
	    {
		pnt = vec.elementAt(i);
		if (pnt.x >= max(0,low_x) && pnt.x <= min(23,high_x) && pnt.y >= max(0,low_y) && pnt.y <= min(23,high_y))
		    filteredVec.add(pnt);
	    }
	return filteredVec;
    }
    
    public boolean playerHasPegs(Vector<Point> vec, int player)
    {
	for (int i = 0; i < vec.size(); i++)
	    {
	        int x = vec.elementAt(i).x;
		int y = vec.elementAt(i).y;
		if (x >= 0 && x <= 23 && y >= 0 && y <= 23)
		    if (pegs[x][y].status == player)
	                return true;
	    }
	return false;
    }
    
    
    /*  Checks if this player has a piece that can be fenced up with it.
	DOES NOT check if it is crossing an enemy fence. This must be added. */
    private Point delta(Point U,Point V){return new Point(U.x-V.x, U.y-V.y);}
    private int cross(Point U, Point V){return U.x*V.y-U.y*V.x;}
    private int min(int x, int y) {return (x<y)?x:y;}
    private int max(int x, int y) {return (x<y)?y:x;}
    
    
    public boolean fenceCollision(Point start, Point end)
    {	
    
        if (outOfBounds(start) || outOfBounds(end))
            return true;
   
	    Point dPoint = delta(end,start);
	
	    for (int i = min(start.x,end.x); i <= max(end.x,start.x); i++)
	        for (int j = min(end.y,start.y); j <= max(end.y,start.y); j++)
		        for (int k = 0; k < pegs[i][j].fenceDests.size(); k++)
	            {
		            Point loc = new Point(i,j);
		            Point fenc = pegs[i][j].fenceDests.elementAt(k);
		            int num = cross(delta(start,loc),delta(end,start));
		            int den = cross(delta(fenc,loc),delta(end,start));
		            if (den !=0)
                    {
			            float test = (float)num/(float)den;
			            if ((test < 2.0/3.0) && (0 < test)) return true;
                    }
		        }
	
	    return false;
    }


    public void addFences(int x, int y)
    {
	if (x-1 >= 0 && y-2 >= 0)
	    if (!(fenceCollision(new Point(x,y),new Point(x-1,y-2))))
		if (pegs[x-1][y-2].status == playerTurn)
		    {
			
			pegs[x-1][y-2].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x-1, y-2));
		    }
	
	if (x+1 <= 23 && y-2 >= 0)
	    if (!(fenceCollision(new Point(x,y),new Point(x+1,y-2))))
	        if (pegs[x+1][y-2].status == playerTurn)
		    {
			pegs[x+1][y-2].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x+1, y-2));
		    }
	
	if (x+2 <= 23 && y-1 >= 0)
	    if (!(fenceCollision(new Point(x,y),new Point(x+2,y-1))))
	        if (pegs[x+2][y-1].status == playerTurn)
		    {
			pegs[x+2][y-1].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x+2, y-1));
		    }
	
	if (x+2 <= 23 && y+1 <= 23)
	    if (!(fenceCollision(new Point(x,y),new Point(x+2,y+1))))
	        if (pegs[x+2][y+1].status == playerTurn)
		    {
			pegs[x+2][y+1].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x+2, y+1));
		    }
	
	if (x+1 <= 23 && y+2 <= 23)
	    if (!(fenceCollision(new Point(x,y),new Point(x+1,y+2))))
	        if (pegs[x+1][y+2].status == playerTurn)
		    {
			pegs[x+1][y+2].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x+1, y+2));
		    }
	
	if (x-1 >= 0 && y+2 <= 23)
	    if (!(fenceCollision(new Point(x,y),new Point(x-1,y+2))))
	        if (pegs[x-1][y+2].status == playerTurn)
		    {
			pegs[x-1][y+2].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x-1, y+2));
		    }
	
        if (x-2 >= 0 && y+1 <= 23)
	    if (!(fenceCollision(new Point(x,y),new Point(x-2,y+1))))
	        if (pegs[x-2][y+1].status == playerTurn)
		    {
			pegs[x-2][y+1].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x-2, y+1));
		    }
	
	if (x-2 >= 0 && y-1 >= 0)
	    if (!(fenceCollision(new Point(x,y),new Point(x-2,y-1))))
	        if (pegs[x-2][y-1].status == playerTurn)
		    {
			pegs[x-2][y-1].addFence(new Point(x, y));
			pegs[x][y].addFence(new Point(x-2, y-1));
		    }
	
    }
    
    
    public boolean placePeg(int x, int y)
    {
        if ((outOfBounds(new Point(x, y))) || (pegs[x][y].status != 0))
            return false;

	    if (playerTurn == 1)
        {
		    if (x == 0 || x == 23)
		        return false;
		    pegs[x][y].status = 1;
        }
	    else if (playerTurn == 2)
	    {
		    if (y == 0 || y == 23)
		        return false;
		        
		    pegs[x][y].status = 2;
        }
	
	    this.addFences(x, y);
	
	    playerPegs.get(playerTurn).add(new Point(x,y));
	    numUsedPegs++;
	    return true;
    }
    
    public boolean removePeg(int x, int y){
        if (outOfBounds(new Point(x, y)))
            return true;
		if (pegs[x][y].status == 0) return false;
		for (int i = 0; i < pegs[x][y].fenceDests.size(); i++){
			Point p = pegs[x][y].fenceDests.elementAt(i);
			pegs[p.x][p.y].fenceDests.remove(new Point(x,y));
		}
		pegs[x][y].fenceDests.removeAllElements();
		pegs[x][y].status = 0;
		numUsedPegs--;
		playerPegs.get(1).remove(new Point(x,y));
		playerPegs.get(2).remove(new Point(x,y));
		return true;
    }

	     
	     /*
		for (int k = 0; k < pegs[i][j].fenceDests.size(); k++)
		    {
			Point loc = new Point(i,j);
			Point fenc = pegs[i][j].fenceDests.elementAt(k);
			int num = cross(delta(start,loc),delta(end,start));
			int den = cross(delta(fenc,loc),delta(end,start));

*/	    
    
    public boolean gameOver(int player)
    {
	/*
	System.err.println("used pegs: " + numUsedPegs);
        if (numUsedPegs > 200 && globals.players[1] != 0 && globals.players[2] != 0)
	    {
		globals.winner = 3;
		return true;
	    }
	*/
	if (player == 1)
	    {
	        for(int x=0; x<24; x++)
		    {
			if (pegs[x][0].status == 1)
			    {
				/*  doing a BFS to see if we get to the other side */
				
				boolean[][] visited = new boolean[24][24];
				
				for (int i=0; i<24; i++)
				    for (int j=0; j<24; j++)
					visited[i][j] = false;
				
				/* using vector like a queue */
				Vector<Point> q = new Vector<Point>();
				q.add(new Point(x, 0));
				visited[x][0] = true;
				while(q.size() != 0)
				    {
					Point p = q.remove(0);
					Vector<Point> dests = pegs[p.x][p.y].fenceDests;
					for (Point d : dests)
					    {
						if (!visited[d.x][d.y])
						    {
							if (d.y == 23)
							    {
								//globals.winner = 1;
								return true;
							    }
							visited[d.x][d.y] = true;
							q.add(d);
						    }
					    }
				    }
			    }
		    }
	    }  
        else if (player == 2)
	    {
		
	        for(int y=0; y<24; y++)
		    {
			if (pegs[0][y].status == 2)
			    {
				/*  doing a BFS to see if we get to the other side */
				
				boolean[][] visited = new boolean[24][24];
				
				for (int i=0; i<24; i++)
				    for (int j=0; j<24; j++)
					visited[i][j] = false;
				
				/* using vector like a queue */                
				Vector<Point> q = new Vector<Point>();
				q.add(new Point(0, y));
				visited[0][y] = true;
				while(q.size() != 0)
				    {
					Point p = q.remove(0);
					Vector<Point> dests = pegs[p.x][p.y].fenceDests;
					for (Point d : dests)
					    {
						if (!visited[d.x][d.y])
						    {
							if (d.x == 23)
							    {
								//globals.winner = 2;
								return true;
							    }
							
							visited[d.x][d.y] = true;
							q.add(d);
						    }
					    }
				    }
			    }
		    }
	    }
        return false;
    }
    
    public static boolean outOfBounds(Point p)
    {
        if (p.x < 0 || p.x > 23 || p.y < 0 || p.y > 23)
            return true;
        return false;
    }
}

