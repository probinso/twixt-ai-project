import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.ArrayList;
import java.lang.Math;

public class GameBoard extends JPanel implements MouseListener
{
    public Peg[][] pegs = new Peg[24][24];
    public int numUsedPegs = 0;
    public Point lastPeg;
    public ArrayList<Vector<Point>> playerPegs = new ArrayList<Vector<Point>>(3);

    public GameBoard()
    {
	    restart();
	    addMouseListener(this);
    }
    

    public ArrayList<Vector<Point>> copyPlayerPegs ()
    {
        Vector<Point> v1 = new Vector<Point> ();
        Vector<Point> v2 = new Vector<Point> ();
        
        Vector<Point> p1 = playerPegs.get(1);
        Vector<Point> p2 = playerPegs.get(2);
        
        for (Point p : p1)
            v1.add(new Point(p.x, p.y));

        for (Point p : p2)
            v2.add(new Point(p.x, p.y));
            
        ArrayList<Vector<Point>> returnPlayerPegs = new ArrayList<Vector<Point>>(3);
        
        returnPlayerPegs.add(new Vector<Point>());
        returnPlayerPegs.add(v1);
        returnPlayerPegs.add(v2);
        
        return returnPlayerPegs;
    }

       
	public Vector<Point> pegRange(Vector<Point> vec, int low_x, int low_y, int high_x, int high_y)
	{
		Vector<Point> filteredVec = new Vector<Point>();
		Point pnt;

		int vLen = vec.size();
		
		for(int i = 0; i < vLen; i++)
		{
			pnt = vec.elementAt(i);
			if (pnt.x >= max(0,low_x) && pnt.x <= min(23,high_x) && pnt.y >= max(0,low_y) && pnt.y <= min(23,high_y))
				filteredVec.add(pnt);
		}
		return filteredVec;
	}
	
	public boolean playerHasPegs(Vector<Point> vec, int player)
	{
	    for (int i = 0; i < vec.size(); i++)
	    {
	        int x = vec.elementAt(i).x;
            int y = vec.elementAt(i).y;
            if (x >= 0 && x <= 23 && y >= 0 && y <= 23)
                if (pegs[x][y].status == player)
	                return true;
	    }
	    return false;
	}


    /* Methods for the game and board */
    public void begin()
	{
        this.restart();
        if ((globals.players[1] != 0) && (globals.players[2] != 0))
        {
            while(globals.winner == 0)
            {
                globals.aiPlayers[globals.players[globals.playerTurn]].makeMove(new BoardStore(this), true);
                globals.playerTurn = (globals.playerTurn == 1) ? 2 : 1;
                globals.mp.updatePlayerTurn();
            }
        }
        else if ((globals.players[globals.playerTurn] > 0) && (globals.winner == 0))
        {
            globals.aiPlayers[globals.players[globals.playerTurn]].makeMove(new BoardStore(this), true);
            globals.playerTurn = (globals.playerTurn == 1) ? 2 : 1;
            globals.mp.updatePlayerTurn();
        }
	}

	public void restart()
	{
    	this.lastPeg = new Point(-3, -3);
	    this.numUsedPegs = 0;

        playerPegs = new ArrayList<Vector<Point>>(3);
	    for(int i = 0; i< 3; i++)
		    this.playerPegs.add(new Vector<Point>());
	    
	    for (int i=0; i<24; i++)
    		for (int j=0; j<24; j++)
	            this.pegs[i][j] = new Peg();
   	    this.repaint();
	}

	public synchronized void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		this.setBackground(Color.WHITE);
		
		if (globals.started)
		{
		    Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(2));

		    g.setColor(Color.BLUE);
		    g.drawLine(33, 30, 693, 30);
		    g.drawLine(33, 691, 693, 691);
		
		    g.setColor(Color.RED);
		    g.drawLine(33, 30, 33, 691);
		    g.drawLine(693, 30, 693, 691);

            g2.setStroke(new BasicStroke(1));

            if (numUsedPegs >= 1)
                g.setColor(Color.YELLOW);
                g.fillOval(lastPeg.x*30+5, lastPeg.y*30+5, 22, 22);

            for (int i=0; i<24; i++)
            {
                for (int j=0; j<24; j++)
                {
                    if (!((i==0 && j==0) || (i==0 && j==23) 
                        || (i==23 && j==0) || (i==23 && j==23)))
                    {
			            g.setColor(Color.BLACK);
			            g.fillOval(i*30+10, j*30+10, 12, 12);

                        Color C = Color.WHITE;

                        if (pegs[i][j].status == 1)
                        {
                            g.setColor(Color.BLUE);

                            Vector<Point> fences = pegs[i][j].fenceDests;
                            for (Point p : fences)
                                g.drawLine(i*30+16, j*30+16, p.x*30+16, p.y*30+16);
                        }
                        else if (pegs[i][j].status == 2)
                        {
                            g.setColor(Color.RED);

                            Vector<Point> fences = pegs[i][j].fenceDests;
                            for (Point p : fences)
                                g.drawLine(i*30+16, j*30+16, p.x*30+16, p.y*30+16);
                        }
                        else
                            g.setColor(Color.WHITE);                         
                        
  			            g.fillOval(i*30+11, j*30+11, 10, 10);   
    		        }
			    }
		    }
		}
	}

	
    /*  Checks if this player has a piece that can be fenced up with it.
	DOES NOT check if it is crossing an enemy fence. This must be added. */
    private Point delta(Point U,Point V){return new Point(U.x-V.x, U.y-V.y);}
    private int cross(Point U, Point V){return U.x*V.y-U.y*V.x;}
    private int min(int x, int y) {return (x<y)?x:y;}
    private int max(int x, int y) {return (x<y)?y:x;}


    public boolean fenceCollision(Point start, Point end)
    {	
	    Point dPoint = delta(end,start);
	
	    for (int i = min(start.x,end.x); i <= max(end.x,start.x); i++)
	        for (int j = min(end.y,start.y); j <= max(end.y,start.y); j++)
		        for (int k = 0; k < pegs[i][j].fenceDests.size(); k++)
		        {
		            Point loc = new Point(i,j);
		            Point fenc = pegs[i][j].fenceDests.elementAt(k);
		            int num = cross(delta(start,loc),delta(end,start));
		            int den = cross(delta(fenc,loc),delta(end,start));
		            if (den !=0)
		            {
			            float test = (float)num/(float)den;
        			    if ((test < 2.0/3.0) && (0 < test)) return true;
		            }
		            
		        }
	
	    return false;
    }

   public boolean fenceCollision(Point start, int x, int y)
   {
        if (x < 0 || x > 23 || y < 0 || y > 24)
            return true;
        return fenceCollision(start, new Point(x,y));
   }
    

	public void addFences(int x, int y)
	{
	    if (x-1 >= 0 && y-2 >= 0)
		if (!(fenceCollision(new Point(x,y),new Point(x-1,y-2))))
		    if (pegs[x-1][y-2].status == globals.playerTurn)
			{
			    
			    pegs[x-1][y-2].addFence(new Point(x, y));
			    pegs[x][y].addFence(new Point(x-1, y-2));
			}
	  
	    if (x+1 <= 23 && y-2 >= 0)
		if (!(fenceCollision(new Point(x,y),new Point(x+1,y-2))))
	        if (pegs[x+1][y-2].status == globals.playerTurn)
	        {
                pegs[x+1][y-2].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x+1, y-2));
	        }
	    
	    if (x+2 <= 23 && y-1 >= 0)
		if (!(fenceCollision(new Point(x,y),new Point(x+2,y-1))))
	        if (pegs[x+2][y-1].status == globals.playerTurn)
	        {
                pegs[x+2][y-1].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x+2, y-1));
	        }
	        
	    if (x+2 <= 23 && y+1 <= 23)
		if (!(fenceCollision(new Point(x,y),new Point(x+2,y+1))))
	        if (pegs[x+2][y+1].status == globals.playerTurn)
	        {
                pegs[x+2][y+1].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x+2, y+1));
	        }
	        
	    if (x+1 <= 23 && y+2 <= 23)
		if (!(fenceCollision(new Point(x,y),new Point(x+1,y+2))))
	        if (pegs[x+1][y+2].status == globals.playerTurn)
	        {
                pegs[x+1][y+2].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x+1, y+2));
	        }
	        
	    if (x-1 >= 0 && y+2 <= 23)
		if (!(fenceCollision(new Point(x,y),new Point(x-1,y+2))))
	        if (pegs[x-1][y+2].status == globals.playerTurn)
	        {
                pegs[x-1][y+2].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x-1, y+2));
	        }
	        
        if (x-2 >= 0 && y+1 <= 23)
	    if (!(fenceCollision(new Point(x,y),new Point(x-2,y+1))))
	        if (pegs[x-2][y+1].status == globals.playerTurn)
	        {
                pegs[x-2][y+1].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x-2, y+1));
	        }
	        
	    if (x-2 >= 0 && y-1 >= 0)
		if (!(fenceCollision(new Point(x,y),new Point(x-2,y-1))))
	        if (pegs[x-2][y-1].status == globals.playerTurn)
	        {
                pegs[x-2][y-1].addFence(new Point(x, y));
                pegs[x][y].addFence(new Point(x-2, y-1));
	        }
	  
	}

    public boolean isHumanTurn()
    {
        return globals.players[globals.playerTurn] == 0;
    }
	
    public boolean placePeg(int x, int y)
    {
        if (x < 0 || x > 23 || y < 0 || y > 23)
            return false;

        if (globals.started && pegs[x][y].status == 0 && globals.winner == 0)
        {
            if (globals.playerTurn == 1)
            {
                if (x == 0 || x == 23)
                    return false;
                pegs[x][y].status = 1;
            }
            else if (globals.playerTurn == 2)
            {
                if (y == 0 || y == 23)
                    return false;
                pegs[x][y].status = 2;
            }

			lastPeg = new Point(x, y);
            this.addFences(x, y);
            this.paintImmediately(this.getVisibleRect());
            this.revalidate();
            
            if (gameOver(globals.playerTurn))
            {
                globals.mp.printGameOver();
            }

            playerPegs.get(globals.playerTurn).add(new Point(x,y));
			numUsedPegs++;
            return true;
        }
        return false;
    }
	
	public boolean gameOver(int player)
	{
        if (numUsedPegs > 200 && globals.players[1] != 0 && globals.players[2] != 0)
        {
            globals.winner = 3;
            return true;
        }

	    if (player == 1)
	    {
	        for(int x=0; x<24; x++)
	        {
	            if (pegs[x][0].status == 1)
                {
                    /*  doing a BFS to see if we get to the other side */
                        
                    boolean[][] visited = new boolean[24][24];
                    
            	    for (int i=0; i<24; i++)
                        for (int j=0; j<24; j++)
                            visited[i][j] = false;

                    /* using vector like a queue */                
                    Vector<Point> q = new Vector<Point>();
                    q.add(new Point(x, 0));
                    visited[x][0] = true;
                    while(q.size() != 0)
                    {
                        Point p = q.remove(0);
                        Vector<Point> dests = pegs[p.x][p.y].fenceDests;
                        for (Point d : dests)
                        {
                            if (!visited[d.x][d.y])
                            {
                                if (d.y == 23)
                                {
                                    globals.winner = 1;
                                    return true;
                                }
                                visited[d.x][d.y] = true;
                                q.add(d);
                            }
                        }
                    }
                }
            }
        }  
        else if (player == 2)
	    {

	        for(int y=0; y<24; y++)
	        {
	            if (pegs[0][y].status == 2)
                {
                    /*  doing a BFS to see if we get to the other side */
                        
                    boolean[][] visited = new boolean[24][24];
                    
            	    for (int i=0; i<24; i++)
                        for (int j=0; j<24; j++)
                            visited[i][j] = false;

                    /* using vector like a queue */                
                    Vector<Point> q = new Vector<Point>();
                    q.add(new Point(0, y));
                    visited[0][y] = true;
                    while(q.size() != 0)
                    {
                        Point p = q.remove(0);
                        Vector<Point> dests = pegs[p.x][p.y].fenceDests;
                        for (Point d : dests)
                        {
                            if (!visited[d.x][d.y])
                            {
                                if (d.x == 23)
                                {
                                    globals.winner = 2;
                                    return true;
                                }

                                visited[d.x][d.y] = true;
                                q.add(d);
                            }
                        }
                    }
                }
            }
        }
        return false;
	}
	
	public void mouseClicked(MouseEvent e)
	{}
	
	public void mouseExited(MouseEvent e)
	{}

	public void mouseEntered(MouseEvent e)
	{}

	public void mouseReleased(MouseEvent e)
	{
	    
	    if (isHumanTurn())
	    {
                int x = (e.getX()-10)/30;
                int errx = (e.getX()-10)%30;

                int y = (e.getY()-10)/30;
                int erry = (e.getY()-10)%30;

                if (errx < 13 && erry < 13)
                    if (placePeg(x, y))
                    {
                        if (globals.winner == 0)
                        {
                            globals.playerTurn = (globals.playerTurn == 1) ? 2 : 1;
                            globals.mp.updatePlayerTurn();
                        }

                        if ((globals.players[globals.playerTurn] > 0) && (globals.winner == 0))
                        {
                            globals.aiPlayers[globals.players[globals.playerTurn]].makeMove(new BoardStore(this), true);
                            globals.playerTurn = (globals.playerTurn == 1) ? 2 : 1;
                            globals.mp.updatePlayerTurn();
                        }
                    }
            }
	}

	public void mousePressed(MouseEvent e)
	{}
}
