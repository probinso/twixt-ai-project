import java.awt.*;

public class globals
{
	public static GameBoard gb = new GameBoard();
    public static MenuPanel mp = new MenuPanel();

    public static int players[] = {-1, -1, -1};
    public static AIBase aiPlayers[] = {null, new AIBase(), new AISimple(1, 0), new AIBlocker(1, 10), new AIAdvancer(2, 1), new AIPlayer(1, 1)};

    public static boolean started = false;
    public static int winner = 0;
    public static int playerTurn = 0;
}
