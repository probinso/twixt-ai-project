import java.awt.*;
import java.util.*;

public class AIPlayer extends AIBase
{
    public AIPlayer(int gWeight, int bWeight)
    {
	    goalWeight = gWeight;
	    blockWeight = bWeight;
    }
	
	public void makeMove(BoardStore bs, boolean realBoard)
    {
        int x = 0;
        int y = 0;
        Point currPoint = new Point(0,0);

        if (bs.numUsedPegs < 4)
        {
            if (bs.numUsedPegs < 2)
            {
                x = randomGenerator.nextInt(12) + 6;
                y = (randomGenerator.nextInt(2) == 1) ? 3 : 20;
                
                if (globals.playerTurn == 2)
                {
                    int a = x;
                    x = y;
                    y = a;   
                }
            }
            else if (bs.numUsedPegs < 4)
            {
                Vector<Point> theirs = bs.playerPegs.get(2);
                Point theirPeg = theirs.elementAt(0);

                if (bs.playerTurn == 1)
                {
                    int a = theirPeg.x;
                    int b = 23 - theirPeg.x;
                    
                    if (a > b)
                    {
                        x = randomGenerator.nextInt(6) - 3 + a/2;
                        y = theirPeg.y;
                    }
                    else
                    {
                        x = randomGenerator.nextInt(6) - 3 + a + b/2;
                        y = theirPeg.y;
                    }
                }
                else
                {
                    int a = theirPeg.y;
                    int b = 23 - theirPeg.y;
                    
                    if (a > b)
                    {
                        y = randomGenerator.nextInt(6) - 3 + a/2;
                        x = theirPeg.x;
                    }
                    else
                    {
                        y = randomGenerator.nextInt(6) - 3 + a + b/2;
                        x = theirPeg.x;
                    }
                }
            }
            currPoint = new Point(x, y);
        }
        else
        {
            abtree ab = new abtree();
            currPoint = ab.ABsearch(bs, 3, this);
        }

        boolean placed = false;

        if (realBoard)
            placed = globals.gb.placePeg(currPoint.x, currPoint.y);
        else
            placed = bs.placePeg(currPoint.x, currPoint.y);

        if (!placed)
        {
            moveType myMoves[] = findMoves(bs);
            Vector<Point> prunedMoves = forwardPrune(myMoves, bs, bs.playerTurn);
            while (!placed)
            {
                if (!prunedMoves.isEmpty())
                {
                    currPoint = prunedMoves.remove(0);
                    x = currPoint.x;
                    y = currPoint.y;					
                }
                else
                {
                    x = randomGenerator.nextInt(24);
                    y = randomGenerator.nextInt(24);
                }
                if (realBoard)
                    placed = globals.gb.placePeg(x, y);
                else
                    placed = bs.placePeg(x, y);
            }
        }   
        return;   
    }
    
    
	public Vector<Point> forwardPrune(moveType[] mt, BoardStore bs, int turn)
	{
	    Vector<Point> allMoves = new Vector<Point>();
		Vector<Point> blocks = mt[1].immediate;
	
	    if (blocks.size() > 0)
	        return blocks;
	        

        /* Adding pattern based advancement moves */
		allMoves.addAll(mt[0].setup);
		allMoves.addAll(mt[0].immediate);
		
		if (turn == 1)
    		Collections.sort(allMoves, ycomp);
        else
            Collections.sort(allMoves, xcomp);

        if (allMoves.size() > 12)
            allMoves.setSize(12);

        /* Adding immediate moves */
        Vector<Point> immediate = new Vector<Point>();
		immediate.addAll(mt[2].immediate);

		if (turn == 1)
    		Collections.sort(immediate, ycomp);
        else
            Collections.sort(immediate, xcomp);

        if (immediate.size() > 12)
            immediate.setSize(12);
        allMoves.addAll(immediate);
        
        /* Adding blocking moves */
        blocks = mt[1].setup;
        if (turn == 1)
    		Collections.sort(blocks, xcomp);
        else
            Collections.sort(blocks, ycomp);

        if (blocks.size() > 8)
            blocks.setSize(8);

        allMoves.addAll(blocks);

        /* Adding random moves */		
        Vector<Point> rand = new Vector<Point> ();
		rand.addAll(mt[0].setup);
    	rand.addAll(mt[0].immediate);
		rand.addAll(mt[1].setup);
    	rand.addAll(mt[1].immediate);
    	rand.addAll(mt[2].immediate);
        if (rand.size() > 5)
        {
            Collections.shuffle(rand);
            rand.setSize(5);
        }
        allMoves.addAll(rand);


        Vector <Point> validMoves = new Vector<Point>();
		boolean added[][] = new boolean[24][24];
		for (int i = 0; i < 24; i++)
			for (int j = 0; j < 24; j++)
			    added[i][j] = false;

        for(Point p : allMoves)
            if (!BoardStore.outOfBounds(p))
                validMoves.add(p);
        
        allMoves = validMoves;

		int x, y;
		Vector<Point> unique = new Vector<Point>(allMoves);
		for(Point p : allMoves)
		{
			x = p.x;
			y = p.y;
            
            if (added[x][y])
                unique.remove(p);
            else
            {
                added[x][y] = true;
			    if (bs.playerTurn == 1)
			    {	
				    if (x == 0 || x == 23)
	    		        unique.remove(p);
			    }
			    else if (bs.playerTurn == 2)
			    {	
				    if (y == 0 || y == 23)
    			        unique.remove(p);
			    }
            }			
		}
		return allMoves;
	}
}
