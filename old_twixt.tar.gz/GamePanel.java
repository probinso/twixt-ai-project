import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel
{
	public GamePanel()
	{
        globals.gb.setMinimumSize(new Dimension(725,755));
        globals.gb.setMaximumSize(new Dimension(725,755));
        globals.gb.setPreferredSize(new Dimension(725,755));
        
        globals.mp.setMinimumSize(new Dimension(180,735));
        globals.mp.setMaximumSize(new Dimension(180,735));
        globals.mp.setPreferredSize(new Dimension(180,735));

		setLayout(new BorderLayout(5, 10));
		add(globals.gb, BorderLayout.WEST);
		add(globals.mp, BorderLayout.EAST);

        globals.mp.begin();
	}

    public synchronized void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		this.setBackground(Color.LIGHT_GRAY);
    }

	public void begin()
	{}
	
	public static void startGame()
	{
//	    globals.gb = new GameBoard();
	    globals.started = true;
        globals.playerTurn = 1;
	    globals.gb.begin();
	}
}
