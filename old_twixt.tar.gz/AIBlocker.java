import java.awt.*;
import java.util.*;

public class AIBlocker extends AIBase
{
    public AIBlocker(int gWeight, int bWeight)
    {
	    goalWeight = gWeight;
	    blockWeight = bWeight;
    }
	
	public void makeMove(BoardStore bs, boolean realBoard)
    {
        int x = 0;
        int y = 0;
        Point currPoint = new Point(0,0);

        if (bs.numUsedPegs < 1)
        {
            x = randomGenerator.nextInt(12) + 6;
            y = (randomGenerator.nextInt(2) == 1) ? 3 : 20;
            currPoint = new Point(x, y);
        }
        else
        {
            abtree ab = new abtree();
            currPoint = ab.ABsearch(bs, 1, this);
        }

        boolean placed = false;

        if (realBoard)
            placed = globals.gb.placePeg(currPoint.x, currPoint.y);
        else
            placed = bs.placePeg(currPoint.x, currPoint.y);

        if (!placed)
        {
            moveType myMoves[] = findMoves(bs);
            Vector<Point> prunedMoves = forwardPrune(myMoves, bs, bs.playerTurn);
            Collections.shuffle(prunedMoves);
            while (!placed)
            {
                if (!prunedMoves.isEmpty())
                {
                    currPoint = prunedMoves.remove(0);
                    x = currPoint.x;
                    y = currPoint.y;
                }
                else
                {   
                    x = randomGenerator.nextInt(24);
                    y = randomGenerator.nextInt(24);
                }
                if (realBoard)
                    placed = globals.gb.placePeg(x, y);
                else
                    placed = bs.placePeg(x, y);
            }
        }   
        return;   
    }
    
    public moveType[] findMoves(BoardStore bs)
	{
		moveType currCollection[] = {new moveType(), new moveType()};
		
		// Gather Blocking Moves
		currCollection[0].addAll(type1BMoves(bs));
		currCollection[0].addAll(type2BMoves(bs));

   		// Gather Single Moves
		currCollection[1].addAll(typeGAMoves(bs));

		return currCollection;
	}

    public Vector<Point> forwardPrune(moveType[] mt, BoardStore bs, int turn)
	{
	    Vector<Point> allMoves = new Vector<Point>();
        boolean added[][] = new boolean[24][24];
		for (int i = 0; i < 24; i++)
			for (int j = 0; j < 24; j++)
			    added[i][j] = false;
        
        boolean blocking = true;
        
        /* If we have blocking moves, thats all we want */
        if ((mt[0].immediate.size()  + mt[0].setup.size()) > 0)
        {
          	allMoves.addAll(mt[0].immediate);  
            allMoves.addAll(mt[0].setup);
    
        }
        else /* Otherwise, adding immediate moves */
        {
            blocking = false;
         	allMoves.addAll(mt[1].immediate);  
        }

		int x, y;
		Vector<Point> unique = new Vector<Point>(allMoves);
		for(Point p : allMoves)
		{
			x = p.x;
			y = p.y;
            
            if (added[x][y])
                unique.remove(p);
            else
            {
                added[x][y] = true;
			    if (bs.playerTurn == 1)
			    {	
				    if (x == 0 || x == 23)
	    		        unique.remove(p);
			    }
			    else if (bs.playerTurn == 2)
			    {	
				    if (y == 0 || y == 23)
    			        unique.remove(p);
			    }
            }			
		}
		
        if (allMoves.size()	 > 20)
	    {
	        if (blocking)
	        {
                Collections.shuffle(allMoves);
                allMoves.setSize(20);
            }
            else
	        {
	            if (turn == 1)
            		Collections.sort(allMoves, ycomp);
                else
                    Collections.sort(allMoves, xcomp);

                allMoves.setSize(20);	
	        }
        }
		
		return allMoves;
	}

	public int evalBoard(int playerTurn, BoardStore bs)
    {
		int p1Score = evalBoardForP1(bs);
		int p2Score = evalBoardForP2(bs);

		//System.err.println("p1Score: " + p1Score + ", p2Score: " + p2Score);

        if (playerTurn == 1)
        	return goalWeight*p1Score - blockWeight*p2Score;
		else if (playerTurn == 2)
        	return goalWeight*p2Score - blockWeight*p1Score;
        else
            return -1000;
    }

    public int evalBoardForP1(BoardStore bs)
    {
        int maxrange = 0;
        int maxconn = 0;
        int maxnear = 0;
        boolean visited[][] = new boolean[24][24];
        for (int i = 0; i < 24; i++)
            for (int j = 0; j < 24; j++)
                visited[i][j] = false;
        
        Vector<Point> P1 = bs.playerPegs.get(1);
        Vector<Point> P2 = bs.playerPegs.get(2);
        
        for (int i = 0; i < P1.size(); i++)
        {
            Vector<Point> q = new Vector<Point>();
            Point peg = P1.elementAt(i);
            if (!visited[peg.x][peg.y])
            {
                q.add(peg);
                int miny = 24;
                int maxy = -1;
                int nearCount = 0;
                int connCount = 0;
                while (!q.isEmpty())
                {
                    Point p = q.remove(0);
                    if (!visited[p.x][p.y])
                    {
                        visited[p.x][p.y] = true;
                        if (bs.pegRange(P2, p.x-1, p.y-1, p.x+1, p.y).size() != 0)
                            for(int k = -2; k <= 2; k++)
                            {
							    if ((p.y < miny) && (bs.pegRange(P2, p.x-1+3*k, 0, p.x+1+3*k, p.y-Math.abs(k)).size() <= 1))
                              	  miny = p.y;
                            }

                        if (bs.pegRange(P2, p.x-1, p.y, p.x+1, p.y+1).size() != 0)
                            for(int k = -2; k <= 2; k++)
                            {
                            	if ((p.y > maxy) && (bs.pegRange(P2, p.x-1+3*k, p.y+Math.abs(k), p.x+1+3*k, 23).size() <= 1))
                              	  maxy = p.y;
                            }

                        Vector<Point> adj = bs.pegs[p.x][p.y].fenceDests;
                        for (int j = 0; j < adj.size(); j++)
                        {
                            connCount++;
                            q.add(adj.elementAt(j));
                        }   
                        Vector<Point> near = bs.pegRange(P1, p.x-4, p.y-4, p.x+4, p.y+4);
                        for (int j = 0; j < near.size(); j++)
                        {
                            Point n = near.elementAt(j);
                            if ((!adj.contains(n))
                                && bs.pegRange(P2, 
                                    java.lang.Math.min(n.x, p.x),
                                    java.lang.Math.min(n.y, p.y),
                                    java.lang.Math.max(n.x, p.x),
                                    java.lang.Math.max(n.y, p.y)).size() == 0)
                            {
                                nearCount++;
                                q.add(n);
                            }    
                        }
                    }
                }
                if (maxy-miny > maxrange)
                {
                    maxrange = maxy-miny;
                    maxconn = connCount;
                    maxnear = nearCount;
                }
            }
        }
        
        
        int value;
        if (maxrange == 23)
            value = 1000;
        else if (maxrange >= 22)
            value = 100;
        else if (maxrange >= 18)
            value = 50;
        else
            value = maxrange;

        return value * maxconn / (maxnear + 1);
    }

    public int evalBoardForP2(BoardStore bs)
    {
        int maxrange = 0;
        int maxconn = 0;
        int maxnear = 0;
        boolean visited[][] = new boolean[24][24];
        for (int i = 0; i < 24; i++)
            for (int j = 0; j < 24; j++)
                visited[i][j] = false;
        
        Vector<Point> P1 = bs.playerPegs.get(1);
        Vector<Point> P2 = bs.playerPegs.get(2);
        
        for (int i = 0; i < P2.size(); i++)
        {
            Vector<Point> q = new Vector<Point>();
            Point peg = P2.elementAt(i);
            if (!visited[peg.x][peg.y])
            {
                q.add(peg);
                int minx = 24;
                int maxx = -1;
                int nearCount = 0;
                int connCount = 0;
                while (!q.isEmpty())
                {
                    Point p = q.remove(0);
                    if (!visited[p.x][p.y])
                    {
                        visited[p.x][p.y] = true;

                        if (bs.pegRange(P1, p.x-1, p.y-1, p.x, p.y+1).size() != 0)
                            for(int k = -2; k <= 2; k++)
                            {
							    if ((p.x < minx) && (bs.pegRange(P1, 0, p.y-1+3*k, p.x-Math.abs(k), p.y+1+3*k).size() <= 1))
                              	  minx = p.x;
                            }

                        if (bs.pegRange(P1, p.x, p.y-1, p.x+1, p.y+1).size() != 0)
                            for(int k = -2; k <= 2; k++)
                            {
                            	if ((p.x > maxx) && (bs.pegRange(P1, p.x+Math.abs(k), p.y-1+3*k, 23, p.y+1+3*k).size() <= 1))
                              	  maxx = p.x;
                            }

                        Vector<Point> adj = bs.pegs[p.x][p.y].fenceDests;
                        for (int j = 0; j < adj.size(); j++)
                        {
                            connCount++;
                            q.add(adj.elementAt(j));
                        }   
                        Vector<Point> near = bs.pegRange(P2, p.x-4, p.y-4, p.x+4, p.y+4);
                        for (int j = 0; j < near.size(); j++)
                        {
                            Point n = near.elementAt(j);
                            if ((!adj.contains(n))
                                && bs.pegRange(P1, 
                                    java.lang.Math.min(n.x, p.x),
                                    java.lang.Math.min(n.y, p.y),
                                    java.lang.Math.max(n.x, p.x),
                                    java.lang.Math.max(n.y, p.y)).size() == 0)
                            {
                                nearCount++;
                                q.add(n);
                            }    
                        }
                    }
                }
                if (maxx-minx > maxrange)
                {
                    maxrange = maxx-minx;
                    maxconn = connCount;
                    maxnear = nearCount;
                }
            }
        }
        
        
        int value;
        if (maxrange == 23)
            value = 1000;
        else if (maxrange >= 22)
            value = 100;
        else if (maxrange >= 18)
            value = 50;
        else
            value = maxrange;

        return value * maxconn / (maxnear + 1);
    }
}
